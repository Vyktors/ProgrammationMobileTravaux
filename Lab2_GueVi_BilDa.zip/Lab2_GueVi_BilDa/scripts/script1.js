function calculer()
{

	var nbr = document.getElementById("txtInput").value;
	

	document.getElementById("container").innerHTML = "";
	
	if(nbr != "")
	{
		
		for(var i = 1; i < 10; i++)
		{
			var resultat = nbr *i;
			document.getElementById("container").innerHTML += i + " * " + nbr+ " = " + resultat +"<br>";
			console.log(resultat);
		}
	}
	
}

		

