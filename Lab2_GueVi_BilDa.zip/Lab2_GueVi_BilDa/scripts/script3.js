var nbrRandom = Math.floor((Math.random() * 5));
var picActu = nbrRandom;
var tab = new Array(5);
tab = ['dora','link','monster','fusil','face'];

//console.log(tab[picActu]);
Actualise();

function Back()
{
	if(picActu==0)
	{
		picActu = 4;
	}
	else
	{
		picActu--;
	}
	
	Actualise();
}

function Next()
{
	if(picActu == 4)
	{
		picActu = 0;
	}
	else
	{
		picActu++;
	}

	Actualise();
}

function Actualise()
{
	document.getElementById("img1").src = 'images/'+tab[picActu] + '.png';
}
