//AJOUTER LISTENER
	var lstBtn = document.getElementsByClassName("add");
	for(var i =0;i<lstBtn.length;i++)
	{
		lstBtn[i].addEventListener("click",change);
	}
	
	
function calculer()
{
	var resultat;
	var nbr = document.getElementById("txtInput").value;
	resultat = eval(nbr);
	//console.log(nbr);
	//console.log(resultat);
	document.getElementById("txtInput").value = resultat;	
}

function clearTxt()
{
	document.getElementById("txtInput").value = "";
}


function change()
{
	var valeur = this.innerHTML;
	//console.log(valeur);
	document.getElementById("txtInput").value += valeur;
}
