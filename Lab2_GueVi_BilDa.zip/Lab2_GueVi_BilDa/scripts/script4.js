var tempT; 
var tempP;

var selection = "";
var cpt = 3;
var lstH1 = document.getElementsByTagName("H1");
	for(var i = 0; i< lstH1.length;i++)
	{
		lstH1[i].addEventListener("click",change);
	}
		
function ajouter()
{	//** Message d'erreur si le titre ou le paragraphe est vide**//
	var txtTitre = document.getElementById("iptTitre").value;
	var txtPar = document.getElementById("iptTexte").value;
	console.log(txtTitre + "," + txtPar)
	
	if(txtPar == "" || txtTitre=="")
	{
		alert("Veuillez remplir le titre et le paragraphe")
	}
	//**Ajout du Titre et du texte en HTML**//
	else
	{	
		
		var newTitre = document.createElement("h1");
		var newP  = document.createElement("p");
		var divParent = document.getElementById("divParent");
		var f = document.getElementById("form1");
		
		newTitre.innerHTML = txtTitre;
		newTitre.id = cpt; 
		newP.innerHTML = txtPar;
		newP.id= "p"+ cpt;cpt++;
		
		divParent.insertBefore(newTitre,f);
		divParent.insertBefore(newP,f);

	}
	
	var lstH1 = document.getElementsByTagName("H1");
	for(var i = 0; i< lstH1.length;i++)
	{
		lstH1[i].addEventListener("click",change);
	}
	
}

function change()
{
	var divParent = document.getElementById("divParent");
	
	if(selection == "")
	{
		
		document.body.style.cursor = 'help';
		selection = this.id;
		selectionP= "p" + this.id;
		console.log(selectionP);
		tempT = document.getElementById(selection);
		tempP = document.getElementById(selectionP);
		
	}else{
		if(selection != this.id)
		{
			selection = this.id;
			var t = document.getElementById(selection);
		 
			divParent.insertBefore(tempT,t);
			divParent.insertBefore(tempP,t);
			
		}
		document.body.style.cursor = 'auto';
		selection ="";
	}
	
	
	
	
}